if (typeof($) != 'undefined') {
    $(function() {
        if ($('input[name=ftp_hostname]').length) {
            $('input[name=ftp_hostname]').focus();
        }
                
    });
}
