<?php

/**
 * Template created by Gregory Chris
 */
load_view('login_screen');