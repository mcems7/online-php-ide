<?php

/**
 * Template created by Gregory Chris
 */


load_view('ide');