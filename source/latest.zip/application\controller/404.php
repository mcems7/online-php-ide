<?php

/**
 * Template created by Gregory Chris
 */


load_view('header');
load_view('404');
load_view('footer');